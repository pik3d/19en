rem  run all *.exe to introduce them to the ANTI-VIRUS

adzip.exe
bell.exe
blur.exe
bot.exe
csv.exe
corr.exe
crex.exe
dif.exe
dim32.exe
ee.exe  Hello antivirus!

eig.exe
svd.exe
diag.exe
ata.exe

pl.exe
filtr.exe
fmt.exe
gauss.exe   /?
gen3d.exe
get.exe
gnoise.exe
hist.exe
inv.exe
join.exe

jj.exe  "tt(\"Hello World\")"

lss.exe
ma.exe

meanc.exe
submeanc.exe

mul.exe
noise.exe
put.exe
renam.exe
rot90.exe

s3d.exe     /?
b3d.exe     /?

setvar.exe
sma.exe
spl.exe
stk.exe
ss.exe
sks.exe
sr.exe
sv.exe
sys.exe

tif.exe

top.exe
tra.exe
tt.exe      /?

usecase.exe
usevec.exe
useout.exe
usestat.exe

vic.exe
vics.exe
vimp.exe
wave.exe

Reverse.exe

pause _____________________ End( 50 ).
