@echo OFF
::        varstk.cmd  VAR  Stk [i=1 [j=1 [k=1 ]]]  !element of Stack ~ set VAR=Stk[i,j,k]
::  e.g.
::        varstk  var stk 3 7
::        echo    stk_3_7 = %var%

for /f %%q in ('setvar stk %2 %3 %4 %5') do ( set %1=%%q )
