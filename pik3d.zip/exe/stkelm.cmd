@echo OFF
::          stkelm.cmd  Stk  ! get Stack Element, %1 = Stack Name
IF [%1]==[] goto end

:cycle
call varkbd i "input i" 3
call varkbd j "input j" 7
call varkbd k "input k(999=exit)" 999

IF %k% equ 999 goto end

call varstk elm %1 %i% %j% %k%
echo %1[ %i%, %j%, %k%] = %elm%
echo.
goto cycle

:end
