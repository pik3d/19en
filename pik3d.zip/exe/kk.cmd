rem KILL ALL running  JAVA  programs
TASKKILL /FI "IMAGENAME eq java*" /f
