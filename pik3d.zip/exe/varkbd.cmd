@echo OFF
::        varkbd.cmd  VAR  prompt [default]  !input value from Keyboard to VAR
::  e.g.
::        varkbd  var "input Value" -999
::        echo    kbd_inp = %var%

for /f %%q in ('setvar kbd %2 %3') do ( set %1=%%q )

