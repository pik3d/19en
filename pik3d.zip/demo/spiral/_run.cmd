rem demo: spiral

jj Fxyt "exp(-(x*x+y*y)/9)*cos(x*x+y*y-t*.2*pi)" "-4,4,.1" "-4,4,.1" "0,9,1" > pp
jj Spiral > spiral
gen3d spiral.gen| get - [7#147, 7#147, :] > ss

s3d ss spiral.s3d , 3 /dbg

del /Q pp Fxyt.s3d spiral ss
