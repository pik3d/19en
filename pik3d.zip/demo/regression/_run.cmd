@echo off
echo.
echo -------------------------------------------------------------------------------------
echo !                                 !!! ATTENTION !!!                                 !
echo ! To run this demo you should download "The Apache Commons Mathematics Library" :   !
echo ! https://archive.apache.org/dist/commons/math/binaries/commons-math3-3.6.1-bin.zip !
echo ! and place  commons-math3-3.6.1.jar (~2.1MB)  to the  ~/pik3d/lib  folder.         !
echo -------------------------------------------------------------------------------------
echo.
pause
echo ___________________________________________________ Regression( x ):

jj Fx  "3-x-3*x*x+x*x*x"  "-1.3,3.41,.05"| join - -[:,2] >XF
stk 95| gnoise - 3| put XF[:,2] - 1 1 @XV| vic - 1 2,-1 "3,0 F(x)" /add=ini #initial

pl "fset: 1, x, x*x, x*x*x" "read: x=X[0],V=X[1]" > f.arg         #create arg.File

jj reglin XV f.arg      >R   &  fmt R   &  fmt R:2    #R-Regression:  {k},  R_sigma
jj regval XV f.arg       R   |  join XV -  >V1        # V1 = chart data   + R

               useout    R s=1.8 @u1|  tt  20*3.0f    #tolerance=1.8*R_sigma, tt u1

jj reglin XV f.arg u1 1 >R1  &  fmt R1  &  fmt R1:2   #R1-Regression: {k}, R1_sigma
jj regval XV f.arg       R1  |  join V1 -  >V2        # V2 = chart data   + R + R1

vic V2 1 2,-1 "3,0 F(x)" "4,0 R" "5,0 R1" /x=626 /add=RR1   #show initial + R + R1

echo ____________________________________________________ Regression( x, y ):

jj  Dat > D                                                            #create Data

pl Points:D,1 Subj.XY:-4,4,-4,4 x,y,W,H:0,394,640,520 >  ini.s3
pl NO_MAP:1 Opac:0 Zmin,MAX:-400,400                  >> ini.s3
pl "head:\n.  initial  Data" Text:15,990099           >> ini.s3      #s3d config

echo ### [2,2]/-400 400 400 -400| s3d - ini.s3                         #initial

jj  reglin  D "1,x,y,x*x,y*y,x*y" "x=X[0],y=X[1],V=X[2]" > R
jj  preFxy  R D > fxy.arg

echo.
echo Regression set of functions:  1, x, y, x*x, y*y, x*y
echo.
echo show Regression:  jj Fxy  "F(x,y)"  "dX: min, Max, dx"  "dY: min, Max, dy"
echo.
     more fxy.arg
echo.
	
pl Points:D,1 Subj.XY:-4,4,-4,4 x,y,W,H:627,394,640,520     >  reg.s3
pl NO_MAP:1 Opac:60 Zmin,MAX:-400,400 Kh:1.25 Shift:0,6     >> reg.s3
pl "head:\n.  restored  Regression ( x, y )" Text:15,990099 >> reg.s3 #s3d config  

jj  Fxy fxy.arg | s3d - reg.s3                                          #restored R  

echo After the pause, all temporary files will be deleted and the charts will be closed.
pause
del /Q  XF, XV, f.arg, V1, u1, R1, V2, D, ini.s3, R, fxy.arg, reg.s3, Fxy.s3d
kk
