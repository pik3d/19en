jj Circle > circle
jj tor > tor.pnt
gen3d lines.gen| s3d - ini.s3d , 3 /dbg
del /Q circle, tor.pnt
