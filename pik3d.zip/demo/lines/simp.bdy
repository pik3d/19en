### Vertex[ 9, 4 ]    ! Vertices
# id    x    y    z
  10   10    10  .5
  11   70    10  .5
  12   70   110  .5
  13   10   110  .5

 -24   30   30  -.6   ! id can be <=0,
 -25   60   30  -.6   ! i.e. mark bottom face
 -26   60   80  -.6
 -27   30   80  -.6

  99   40   70  1.8   ! top vertex

### Faces[ 8, 4 ]     ! Face = quadrangle with vertices: id1, id2, id3, id4
  11  10 -24 -25      !        may be triangle = repeat last vertex
  12  11 -25 -26
  13  12 -26 -27
 -27 -24  10  13

  10  11  99  99      ! triangle
  12  13  99  99

  10  11  12  13
 -27 -26 -25 -24      ! counterclockwise
