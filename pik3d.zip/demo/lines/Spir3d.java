package usr;
/**
 * ��������� 3D-��������� �������:  jj Spir3d.java > spi3d 
 */ 
public class Spir3d extends pik.io {
  static public void main( String[] a ) {
    int n=40, m=n*9;
    double f, df=2*Math.PI/n, x,z, y=5,dy=.3, R=20;

    tt("### spir3d[ "+m+", 3 ]");
    for(int i=0; i<m; i++) {
      f = i*df; 
      x = R*Math.cos( f )+40;
      z =   Math.sin( f )+.25;
//    tt(x+" \t"+y+" \t"+z);
      tt(d7(x)+" "+d7(y)+" "+d7(z));
      y+=dy;
    }
    clott();
  }
}
