package usr;
/**
 * Circle R=1( for dxy: @circle ):  jj Circle.java > circle
 */ 
public class Circle extends pik.io
{
  static public void main( String[] a )
  {
    int n=40; double x, dx=2*Math.PI/n, c, s;
    tt("### dxy[ "+n+", 2 ]");
    for(int i=0; i<n; i++) {
      x = i*dx; 
      c = Math.cos( x );
      s = Math.sin( x );
      tt(c+" \t"+s);
    }
    clott();
  }
}
