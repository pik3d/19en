@echo off
for /L %%i in (0,1,67) do echo .
echo To close ALL demo-windows

rem  Middle top window: Logarithmic Axes
jj log| vics - 1 2,,k=5 3,,k=6 4,,k=7 5,,k=8 6,,k=9 7,,k=10 8,,k=11 /lgyx /x=632 /y=8 /w=596 /h=400 /add=Log

rem  Top right window: Histogram of Gaussian/ normally distributed noise:
stk 1000 1000| gnoise - 1| hist - 1 /add=hist

rem  lower plot, sum of harmonics: minor( frequencies: 1, 6/5, 3/2 ), MAJOR( frequencies: 1, 5/4, 3/2 )
jj minMAJ| vics - 1 "2 1 0 minor_: 1, 6/5, 3/2" "3 8 0 MAJOR: 1, 5/4, 3/2" /y=408 /w=1860 /add=minor

rem  Top left window: Spline of 7-parts using the Least Squares Method:
jj TestLSS| lss - 7 /vis /add=Lss7

pause
TASKKILL /FI "IMAGENAME eq java*" /f
