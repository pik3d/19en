jj Warp > warp
gen3d warp.gen| s3d - init.s3d , 3
del /Q warp 
