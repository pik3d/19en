package usr;
/**
 * Create "Warp" ;-)  x,y - circle, z - Sin.  run:  jj Warp.java > warp 
 * of kilyashenko@gmail.com
 */ 
public class Warp extends pik.io {
  static public void main( String[] a ) {
    int n=20; double x, dx=2*Math.PI/n, c, s;
    tt("### xyh,dxy[ "+(n+1)+", 3 ]");
    for(int i=0; i<=n; i++) {
      x = i*dx; 
      c = Math.cos( x );
      s = Math.sin( x );
      tt(c+" \t"+s+" \t"+s);
    }
    clott();
  }
}
