
The steps below illustrate the interactive tools:
   - smoothing ^B - "Gauss Blur";
   - choice of axes ^O .

Run: _run.cmd, stop at frame 10-14 <space> .
Press the buttons in sequence:

   ^B <Tab> 2 <Enter> <Enter>
   ^O <Tab> <Tab> 12 <Tab> <Tab> -6 <Enter> <Enter>

( from the slider to slider you can switch using the arrows: UP/DOWN )

Rotate the image with the mouse while pressing the left mouse button.

   ^B
      <RIGHT arrow> press and hold until the picture stops
      <LEFT arrow> press and hold until the picture stops

   <Esc>
