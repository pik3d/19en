
gen3d bell2.gen| s3d - bell2.s3d , 3
