rem  demo: body

jj torBod > tor.pnt
b3d simple0 ini.b3d /dbg

jj torus 100   | b3d - tors.b3d /dbg

jj torus 100 .7| b3d - torp.b3d /dbg

del /Q tor.pnt
