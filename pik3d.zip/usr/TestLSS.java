  package usr;
  public class TestLSS {
    static public void main( String[] a ) {
      int i, n=30, nn=n*3;
      double dx=2*Math.PI/n, x=.6, Fun;
      System.out.println("### XYF [ "+nn+", 3 ]");  // XY +Function
      for(i=0; i<nn; i++) {
        Fun = 3*Math.sin( x )*Math.exp( -x/7 );
        System.out.println( x+" \t"+(Fun+(Math.random()-.5))+" \t"+Fun);
        x+=dx;
      }
    }
  }
