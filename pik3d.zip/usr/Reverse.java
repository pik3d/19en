package usr;
import pik.io;                         // library

public class Reverse extends io {
  public static void main( String[] arg ) throws Exception {
    er1("reverse", arg, "Stk > ktS");  // checking input parameters

    var stk = inStk( arg[0] );         // stk[ kk ][ ii ][ jj ]

    int k = stk.length;
    while(--k >=0 ) ttKadr( stk[k] );  // out Frames in Reverse
    clott();
  }
}
