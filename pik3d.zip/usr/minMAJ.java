public class minMAJ {
  static public void main( String[] a )
  {
    System.out.println("### minMAJ [ 201, 3 ]");                 // ### Header
    for(int i=0; i<=200; i++) {
      var t = i*( 2*Math.PI/10 );                                // 10 points/period
      var k = Math.sin( t ) + Math.sin( t*3/2 );                 // tonic + quint
      System.out.println( i/10.+"\t"+( k + Math.sin( t*6/5 ))    // minor
                               +"\t"+( k + Math.sin( t*5/4 )));  // MAJOR
    }
  }
}