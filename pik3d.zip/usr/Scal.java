package com.org.calc.aa.bb.cc;      // Strange package name only for demo. purposes

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Scal
{
  public static void main( String[] arg ){ new Scal( arg );}
  String gets(){
    try {
      return new BufferedReader( new InputStreamReader( System.in )).readLine().trim();
    } catch( Exception e){ q("\n"); return "";}
  }
  Scal( String[] arg ){
     while( true ){
        q("scal:  A (+-*/^) B,  if A|B=, -\"use last result\", (blank=exit): ");
        try {
           var s=gets();  int i=0;
           if( s.isBlank()) break;
           while( ++i < s.length()){
              var op=s.substring( i,i+1 );
              if("+-*/^".contains( op )){
                 double a = pars( s.substring( 0,i )), b = pars( s.substring( i+1 ));
                 switch ( op ) {
                   case "+" -> c=a+b;
                   case "-" -> c=a-b;
                   case "*" -> c=a*b;
                   case "/" -> c=a/b;
                   case "^" -> c=Math.pow( a,b );
                 }
                 q("\t\t\t\t\t\t\t\t"+c); break;
              }
           } q("\n");
        } catch( Exception e){ q("\n");}
     }
     q("__________________ end.\n");
  }
  double c=0;
  double pars( String s ){
     s=s.trim(); return s.startsWith(",")? c: Double.parseDouble( s );
  }
  void q( String s ){ System.err.print( s );}
}