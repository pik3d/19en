  package usr;
  public class Spiral {
    static public void main( String[] a ) {
      int i, n=15, nn=n*3;
      double f=0, df=-2*Math.PI/n, r=10, dr=2.35, h=1, dh=-.015;

      System.out.println("### xyh [ "+nn+", 3 ]");
      for(i=0; i<nn; i++) {
        System.out.println( r*Math.cos( f )+" \t"+r*Math.sin( f )+" \t"+h );
        r+=dr; f+=df; h+=dh;
      }
    }
  }