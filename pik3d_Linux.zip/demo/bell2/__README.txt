
The steps below illustrate the interactive tools:
   - ^B - smoothing - "Gauss Blur";
   - ^X - MAX/min of Z-axes ;
   - ^O - Opacity changing.

Run: _run.cmd, stop at frame 10-14 <space> .
Press the buttons in sequence:

   ^B <Tab> 2 <Enter> <Enter>
   ^X <Tab> <Tab> 12 <Tab> <Tab> -6 <Enter> <Enter>

( from the slider to slider you can switch using the arrows: UP/DOWN )

Rotate the image with the mouse while pressing the left mouse button.

  ^B                   ! Blur changing:
     <arrow RIGHT>     ! press and hold until the picture stops.
     <arrow LEFT>      ! press and hold until you reach a convenient Blur.
  <Esc>

  ^O                   ! Opacity changing:
     try <Home>/<End>
     <input new Value> or select by Mouse
  <Enter>
