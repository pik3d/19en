package usr;
import java.util.*;
import pik.*;
public class dbg extends io {
  public static void main( String[] arg ){
    try{ new dbg(arg); clott();}
    catch( Exception e ){ e.printStackTrace();}
  }
  dbg(String[] arg) throws Exception
  {
    var ff="dbg";
    er1(ff, arg, "ii [ jj=1 [ kk=1 ]]  >  File\n"
    +"\nCreate Stack[ ii, jj, kk ], v[i,j,k]=i*100+j*10+k, 'ijk'"
    +"\nE.g.> jj dbg 4 7 2| tt");

    var s=""; for(var q:arg)s+=" "+q;
    double[] dd = getPars ( s, 1,1,1 );
    int ii = (int)dd[0], jj = (int)dd[1], kk = (int) dd[2], i,j,k=0;
    float bb[][] = new float[ ii ][ jj ];

    while(++k<=kk) {
      tt("### dbg.."+k+"[ "+ii+", "+jj+" ]");
      for(i=1;i<=ii;i++) {
        s="";
        for(j=1;j<=jj;j++) s+=" "+i+j+k;
        tt(s);
      }
      tt();
    }
    clott();
  }
}
