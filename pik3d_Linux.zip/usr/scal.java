package com.org.scal.aa.bb.cc;      // Strange package name only for demo. purposes

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class scal
{
  public static void main( String[] arg ){ new scal( arg );}
  String gets(){
    try {
      return new BufferedReader( new InputStreamReader( System.in )).readLine().trim();
    } catch( Exception e){ q(); return "";}
  }
  scal( String[] arg ){
     while( true ){
        q("Calc: A (+-*/^) B, (blank=exit): ");
        try {
           var s=gets();  int i=0;
           if( s.isBlank()) break;
           while( ++i < s.length()){
              var op=s.substring( i,i+1 );
              if("+-*/^".contains( op )){
                 double a = Double.parseDouble( s.substring( 0,i )),
                        b = Double.parseDouble( s.substring( i+1 )), c=0;
                 switch ( op ) {
                   case "+" -> c=a+b;
                   case "-" -> c=a-b;
                   case "*" -> c=a*b;
                   case "/" -> c=a/b;
                   case "^" -> c=Math.pow( a,b );
                 }
                 q("\t\t\t\t "+c); break;
              }
           } q();
        } catch( Exception e){ q();}
     }
     q("__________________ end.\n");
  }
  void q( String s ){ System.err.print( s );}
  void q(){ q("\n");}
}
